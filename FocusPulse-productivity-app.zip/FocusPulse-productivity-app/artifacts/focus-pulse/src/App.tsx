import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { FocusTimer } from '@/components/focus-timer';
import { TodayTasks } from '@/components/today-tasks';
import { useFocusPulse } from '@/hooks/use-focus-pulse';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  Link,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const {
    tasks,
    sessions,
    timer,
    completion,
    addTask,
    updateTask,
    toggleTask,
    deleteTask,
    selectMode,
    startTimer,
    pauseTimer,
    resetTimer,
    dismissCompletion,
  } = useFocusPulse();
  const today = new Intl.DateTimeFormat('en', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
  }).format(new Date());

  return (
    <main className="workspace-shell">
      <div className="ambient-shape ambient-one" aria-hidden="true" />
      <div className="ambient-shape ambient-two" aria-hidden="true" />
      <div className="workspace">
        <header className="topbar fade-up">
          <Link className="brand" href="/" aria-label="FocusPulse home" data-testid="link-home">
            <span className="brand-mark" aria-hidden="true">
              <span />
              <span />
              <span />
            </span>
            <span className="brand-name">focus<span>pulse</span></span>
          </Link>
          <div className="local-note" data-testid="status-local-storage">
            <span className="local-dot" />
            YOUR SPACE, ON THIS DEVICE
          </div>
        </header>

        <section className="welcome fade-up delay-1">
          <div className="welcome-date">{today.toUpperCase()}</div>
          <h1 className="serif">Find your <em>flow.</em></h1>
          <p>A softer way to make room for what matters.</p>
        </section>

        <div className="dashboard-grid">
          <FocusTimer
            timer={timer}
            focusSessions={sessions.filter((session) => session.mode === 'focus').length}
            completion={completion}
            onModeChange={selectMode}
            onStart={startTimer}
            onPause={pauseTimer}
            onReset={resetTimer}
            onDismissCompletion={dismissCompletion}
          />
          <TodayTasks
            tasks={tasks}
            onAdd={addTask}
            onUpdate={updateTask}
            onToggle={toggleTask}
            onDelete={deleteTask}
          />
        </div>

        <footer className="page-footer fade-up delay-2">
          <span className="footer-line" />
          <p>Take it moment by moment.</p>
          <span className="footer-line" />
        </footer>
      </div>
    </main>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
