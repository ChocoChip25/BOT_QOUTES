import { useCallback, useEffect, useMemo, useState } from 'react';

export type FocusMode = 'focus' | 'short' | 'long';

export type Task = {
  id: string;
  title: string;
  completed: boolean;
  createdAt: string;
};

export type Session = {
  id: string;
  completedAt: string;
  mode: FocusMode;
  durationSeconds: number;
};

export type TimerState = {
  mode: FocusMode;
  endAt: number | null;
  remainingSeconds: number;
  isRunning: boolean;
};

const TASKS_KEY = 'focuspulse.tasks.v1';
const SESSIONS_KEY = 'focuspulse.sessions.v1';
const TIMER_KEY = 'focuspulse.timer.v1';

export const MODE_SECONDS: Record<FocusMode, number> = {
  focus: 25 * 60,
  short: 5 * 60,
  long: 15 * 60,
};

function readStorage<T>(key: string, fallback: T, parse: (value: unknown) => T): T {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? parse(JSON.parse(raw)) : fallback;
  } catch {
    return fallback;
  }
}

function writeStorage(key: string, value: unknown): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Keep the workspace usable when browser storage is unavailable or full.
  }
}

function parseTasks(value: unknown): Task[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.filter((item): item is Task => {
    return Boolean(
      item &&
      typeof item.id === 'string' &&
      typeof item.title === 'string' &&
      typeof item.completed === 'boolean' &&
      typeof item.createdAt === 'string'
    );
  });
}

function parseSessions(value: unknown): Session[] {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.filter((item): item is Session => {
    return Boolean(
      item &&
      typeof item.id === 'string' &&
      typeof item.completedAt === 'string' &&
      ['focus', 'short', 'long'].includes(item.mode) &&
      typeof item.durationSeconds === 'number' &&
      Number.isFinite(item.durationSeconds)
    );
  });
}

function parseTimer(value: unknown): TimerState {
  const fallback: TimerState = {
    mode: 'focus',
    endAt: null,
    remainingSeconds: MODE_SECONDS.focus,
    isRunning: false,
  };
  if (!value || typeof value !== 'object') {
    return fallback;
  }
  const candidate = value as Partial<TimerState>;
  const mode = ['focus', 'short', 'long'].includes(String(candidate.mode))
    ? candidate.mode as FocusMode
    : 'focus';
  const isRunning = candidate.isRunning === true && typeof candidate.endAt === 'number';
  const remainingSeconds = isRunning
    ? Math.max(0, Math.ceil((Number(candidate.endAt) - Date.now()) / 1000))
    : Number.isFinite(candidate.remainingSeconds)
      ? Math.max(0, Math.min(MODE_SECONDS[mode], Number(candidate.remainingSeconds)))
      : MODE_SECONDS[mode];
  return {
    mode,
    endAt: isRunning ? Number(candidate.endAt) : null,
    remainingSeconds,
    isRunning,
  };
}

function localDayKey(date: Date): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}

export function useFocusPulse() {
  const [tasks, setTasks] = useState<Task[]>(() => readStorage(TASKS_KEY, [], parseTasks));
  const [sessions, setSessions] = useState<Session[]>(() => readStorage(SESSIONS_KEY, [], parseSessions));
  const [timer, setTimer] = useState<TimerState>(() => readStorage(TIMER_KEY, parseTimer({
    mode: 'focus',
    endAt: null,
    remainingSeconds: MODE_SECONDS.focus,
    isRunning: false,
  }), parseTimer));
  const [now, setNow] = useState(Date.now());
  const [completion, setCompletion] = useState<FocusMode | null>(null);

  useEffect(() => {
    writeStorage(TASKS_KEY, tasks);
  }, [tasks]);

  useEffect(() => {
    writeStorage(SESSIONS_KEY, sessions);
  }, [sessions]);

  useEffect(() => {
    writeStorage(TIMER_KEY, timer);
  }, [timer]);

  useEffect(() => {
    const intervalId = window.setInterval(() => setNow(Date.now()), 30_000);
    return () => window.clearInterval(intervalId);
  }, []);

  useEffect(() => {
    if (!timer.isRunning || timer.endAt === null) {
      return undefined;
    }
    const update = () => {
      const remaining = Math.max(0, Math.ceil((timer.endAt! - Date.now()) / 1000));
      if (remaining === 0) {
        const finishedMode = timer.mode;
        setTimer({
          mode: finishedMode,
          endAt: null,
          remainingSeconds: 0,
          isRunning: false,
        });
        setCompletion(finishedMode);
        if (finishedMode === 'focus') {
          setSessions((current) => [
            {
              id: crypto.randomUUID(),
              completedAt: new Date().toISOString(),
              mode: finishedMode,
              durationSeconds: MODE_SECONDS.focus,
            },
            ...current,
          ]);
        }
        return;
      }
      setTimer((current) => {
        if (!current.isRunning || current.endAt !== timer.endAt) {
          return current;
        }
        if (current.remainingSeconds === remaining) {
          return current;
        }
        return { ...current, remainingSeconds: remaining };
      });
    };
    update();
    const intervalId = window.setInterval(update, 250);
    return () => window.clearInterval(intervalId);
  }, [timer.endAt, timer.isRunning, timer.mode]);

  const todaySessions = useMemo(() => {
    const today = localDayKey(new Date(now));
    return sessions.filter((session) => localDayKey(new Date(session.completedAt)) === today);
  }, [now, sessions]);

  const addTask = useCallback((title: string) => {
    const cleanTitle = title.trim();
    if (!cleanTitle) {
      return;
    }
    setTasks((current) => [
      ...current,
      {
        id: crypto.randomUUID(),
        title: cleanTitle,
        completed: false,
        createdAt: new Date().toISOString(),
      },
    ]);
  }, []);

  const updateTask = useCallback((id: string, title: string) => {
    const cleanTitle = title.trim();
    if (!cleanTitle) {
      return;
    }
    setTasks((current) => current.map((task) => task.id === id ? { ...task, title: cleanTitle } : task));
  }, []);

  const toggleTask = useCallback((id: string) => {
    setTasks((current) => current.map((task) => task.id === id ? { ...task, completed: !task.completed } : task));
  }, []);

  const deleteTask = useCallback((id: string) => {
    setTasks((current) => current.filter((task) => task.id !== id));
  }, []);

  const selectMode = useCallback((mode: FocusMode) => {
    setTimer({
      mode,
      endAt: null,
      remainingSeconds: MODE_SECONDS[mode],
      isRunning: false,
    });
    setCompletion(null);
  }, []);

  const startTimer = useCallback(() => {
    setTimer((current) => {
      if (current.isRunning) {
        return current;
      }
      const remainingSeconds = current.remainingSeconds || MODE_SECONDS[current.mode];
      return {
        ...current,
        remainingSeconds,
        endAt: Date.now() + remainingSeconds * 1000,
        isRunning: true,
      };
    });
    setCompletion(null);
  }, []);

  const pauseTimer = useCallback(() => {
    setTimer((current) => {
      if (!current.isRunning || current.endAt === null) {
        return current;
      }
      return {
        ...current,
        endAt: null,
        remainingSeconds: Math.max(0, Math.ceil((current.endAt - Date.now()) / 1000)),
        isRunning: false,
      };
    });
  }, []);

  const resetTimer = useCallback(() => {
    setTimer((current) => ({
      mode: current.mode,
      endAt: null,
      remainingSeconds: MODE_SECONDS[current.mode],
      isRunning: false,
    }));
    setCompletion(null);
  }, []);

  const dismissCompletion = useCallback(() => setCompletion(null), []);

  return {
    tasks,
    sessions: todaySessions,
    timer,
    completion,
    addTask,
    updateTask,
    toggleTask,
    deleteTask,
    selectMode,
    startTimer,
    pauseTimer,
    resetTimer,
    dismissCompletion,
  };
}
