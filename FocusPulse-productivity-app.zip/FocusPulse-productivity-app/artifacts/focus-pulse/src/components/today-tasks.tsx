import { Check, Circle, Pencil, Plus, X, Trash2 } from 'lucide-react';
import { useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import type { Task } from '@/hooks/use-focus-pulse';

type TodayTasksProps = {
  tasks: Task[];
  onAdd: (title: string) => void;
  onUpdate: (id: string, title: string) => void;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
};

export function TodayTasks({ tasks, onAdd, onUpdate, onToggle, onDelete }: TodayTasksProps) {
  const [newTitle, setNewTitle] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingTitle, setEditingTitle] = useState('');
  const addInputRef = useRef<HTMLInputElement>(null);
  const completedCount = tasks.filter((task) => task.completed).length;

  function submitNewTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!newTitle.trim()) {
      addInputRef.current?.focus();
      return;
    }
    onAdd(newTitle);
    setNewTitle('');
    addInputRef.current?.focus();
  }

  function beginEdit(task: Task) {
    setEditingId(task.id);
    setEditingTitle(task.title);
  }

  function saveEdit(event: FormEvent<HTMLFormElement>, id: string) {
    event.preventDefault();
    if (editingTitle.trim()) {
      onUpdate(id, editingTitle);
      setEditingId(null);
    }
  }

  function cancelOnEscape(event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === 'Escape') {
      setEditingId(null);
    }
  }

  return (
    <section className="tasks-card fade-up delay-1" aria-labelledby="tasks-heading" data-testid="section-today-tasks">
      <header className="tasks-header">
        <div>
          <div className="eyebrow">A CLEAR LITTLE LIST</div>
          <h2 className="serif tasks-heading" id="tasks-heading">Today, gently.</h2>
          <p className="tasks-subtitle">Small steps still move you forward.</p>
        </div>
        <div className="task-progress" aria-label={`${completedCount} of ${tasks.length} tasks complete`} data-testid="value-task-progress">
          <span className="task-progress-value">{String(completedCount).padStart(2, '0')}<span> / {String(tasks.length).padStart(2, '0')}</span></span>
          <span className="task-progress-caption">done</span>
        </div>
      </header>

      <form className="add-task-form" onSubmit={submitNewTask}>
        <label className="sr-only" htmlFor="new-task">Add a task for today</label>
        <input
          ref={addInputRef}
          id="new-task"
          type="text"
          value={newTitle}
          onChange={(event) => setNewTitle(event.target.value)}
          placeholder="What would feel good to finish?"
          maxLength={140}
          autoComplete="off"
          data-testid="input-new-task"
        />
        <button type="submit" aria-label="Add task" data-testid="button-add-task">
          <Plus size={18} />
          <span>Add</span>
        </button>
      </form>

      {tasks.length === 0 ? (
        <div className="task-empty" data-testid="empty-tasks">
          <div className="empty-mark" aria-hidden="true"><span /><span /><span /></div>
          <p className="empty-title">A fresh page.</p>
          <p className="empty-copy">Add one thing you’d like to make room for today.</p>
        </div>
      ) : (
        <ul className="task-list" aria-label="Today's tasks">
          {tasks.map((task, index) => (
            <li className={`task-row ${task.completed ? 'is-complete' : ''}`} key={task.id} data-testid={`row-task-${task.id}`}>
              <button
                className="task-check"
                type="button"
                aria-label={`${task.completed ? 'Mark as not complete' : 'Complete'}: ${task.title}`}
                aria-pressed={task.completed}
                onClick={() => onToggle(task.id)}
                data-testid={`button-toggle-task-${task.id}`}
              >
                {task.completed ? <Check size={14} strokeWidth={2.5} /> : <Circle size={19} strokeWidth={1.5} />}
              </button>
              {editingId === task.id ? (
                <form className="edit-task-form" onSubmit={(event) => saveEdit(event, task.id)}>
                  <label className="sr-only" htmlFor={`edit-task-${task.id}`}>Edit task</label>
                  <input
                    id={`edit-task-${task.id}`}
                    value={editingTitle}
                    onChange={(event) => setEditingTitle(event.target.value)}
                    onKeyDown={cancelOnEscape}
                    maxLength={140}
                    autoFocus
                    data-testid={`input-edit-task-${task.id}`}
                  />
                  <button className="mini-icon save-edit" type="submit" aria-label="Save task" data-testid={`button-save-task-${task.id}`}><Check size={16} /></button>
                  <button className="mini-icon" type="button" aria-label="Cancel editing" onClick={() => setEditingId(null)} data-testid={`button-cancel-edit-${task.id}`}><X size={16} /></button>
                </form>
              ) : (
                <>
                  <span className="task-index mono">{String(index + 1).padStart(2, '0')}</span>
                  <span className="task-title" data-testid={`text-task-title-${task.id}`}>{task.title}</span>
                  <div className="task-actions">
                    <button className="mini-icon" type="button" aria-label={`Edit ${task.title}`} onClick={() => beginEdit(task)} data-testid={`button-edit-task-${task.id}`}><Pencil size={15} /></button>
                    <button className="mini-icon delete-task" type="button" aria-label={`Delete ${task.title}`} onClick={() => onDelete(task.id)} data-testid={`button-delete-task-${task.id}`}><Trash2 size={15} /></button>
                  </div>
                </>
              )}
            </li>
          ))}
        </ul>
      )}
      <footer className="tasks-footer" data-testid="status-tasks">
        <span className="footer-spark" aria-hidden="true" />
        {tasks.length > 0 && completedCount === tasks.length
          ? 'You made space for everything on your list.'
          : tasks.length > 0
            ? `${tasks.length - completedCount} ${tasks.length - completedCount === 1 ? 'thing' : 'things'} left, one at a time.`
            : 'No rush. Start with whatever feels lightest.'}
      </footer>
    </section>
  );
}
