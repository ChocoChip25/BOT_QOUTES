import { Check, Pause, Play, RotateCcw } from 'lucide-react';
import { MODE_SECONDS, type FocusMode, type TimerState } from '@/hooks/use-focus-pulse';

type FocusTimerProps = {
  timer: TimerState;
  focusSessions: number;
  completion: FocusMode | null;
  onModeChange: (mode: FocusMode) => void;
  onStart: () => void;
  onPause: () => void;
  onReset: () => void;
  onDismissCompletion: () => void;
};

const modes: { id: FocusMode; label: string; shortLabel: string }[] = [
  { id: 'focus', label: 'Focus', shortLabel: 'Focus' },
  { id: 'short', label: 'Short break', shortLabel: 'Short break' },
  { id: 'long', label: 'Long break', shortLabel: 'Long break' },
];

function formatTime(totalSeconds: number): string {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

export function FocusTimer({
  timer,
  focusSessions,
  completion,
  onModeChange,
  onStart,
  onPause,
  onReset,
  onDismissCompletion,
}: FocusTimerProps) {
  const duration = MODE_SECONDS[timer.mode];
  const progress = duration ? ((duration - timer.remainingSeconds) / duration) * 100 : 0;
  const title = timer.mode === 'focus' ? 'A little space to focus.' : 'Take a moment for yourself.';
  const description = timer.mode === 'focus'
    ? 'One thing at a time. You’re right where you need to be.'
    : 'Step away from the list. Let your mind wander a little.';

  return (
    <section className="timer-card fade-up" aria-labelledby="timer-heading" data-testid="section-focus-timer">
      <div className="timer-card-top">
        <div>
          <div className="eyebrow"><span className="pulse-dot" /> YOUR FOCUS SPACE</div>
          <h2 id="timer-heading" className="serif timer-heading">{title}</h2>
          <p className="timer-description">{description}</p>
        </div>
        <div className="session-count" aria-label={`${focusSessions} focus sessions completed today`} data-testid="value-focus-sessions">
          <span className="count-number">{String(focusSessions).padStart(2, '0')}</span>
          <span className="count-label">sessions<br />today</span>
        </div>
      </div>

      <div className="mode-tabs" role="group" aria-label="Timer mode">
        {modes.map((mode) => (
          <button
            key={mode.id}
            type="button"
            className={`mode-tab ${timer.mode === mode.id ? 'active' : ''}`}
            aria-pressed={timer.mode === mode.id}
            onClick={() => onModeChange(mode.id)}
            data-testid={`button-mode-${mode.id}`}
          >
            {mode.label}
            <span className="mode-length">{MODE_SECONDS[mode.id] / 60} min</span>
          </button>
        ))}
      </div>

      <div className="timer-stage">
        <div className="timer-orbit" aria-hidden="true">
          <svg viewBox="0 0 260 260" className="timer-ring">
            <circle className="ring-track" cx="130" cy="130" r="116" />
            <circle
              className="ring-progress"
              cx="130"
              cy="130"
              r="116"
              style={{ strokeDasharray: `${2 * Math.PI * 116}`, strokeDashoffset: `${2 * Math.PI * 116 * (1 - Math.max(0, Math.min(progress, 100)) / 100)}` }}
            />
          </svg>
          <div className="timer-center">
            <span className="timer-mode-caption">{timer.isRunning ? 'IN THE FLOW' : timer.mode === 'focus' ? 'READY WHEN YOU ARE' : 'A MOMENT TO RESET'}</span>
            <span className="timer-digits mono" role="timer" aria-label={`${Math.floor(timer.remainingSeconds / 60)} minutes ${timer.remainingSeconds % 60} seconds remaining`} data-testid="value-timer">
              {formatTime(timer.remainingSeconds)}
            </span>
            <span className="timer-hint">{timer.isRunning ? 'Your focus is underway' : 'Make this moment yours'}</span>
          </div>
          <span className="orbit-speck speck-one" />
          <span className="orbit-speck speck-two" />
        </div>
      </div>

      <div className="timer-controls">
        <button
          className="primary-action"
          type="button"
          onClick={timer.isRunning ? onPause : onStart}
          data-testid={timer.isRunning ? 'button-pause-timer' : 'button-start-timer'}
        >
          {timer.isRunning ? <Pause size={17} strokeWidth={2.2} /> : <Play size={17} strokeWidth={2.2} fill="currentColor" />}
          <span>{timer.isRunning ? 'Pause for a moment' : timer.remainingSeconds === duration ? `Begin ${timer.mode === 'focus' ? 'focus' : 'break'}` : `Resume ${timer.mode === 'focus' ? 'focus' : 'break'}`}</span>
        </button>
        <button
          className="reset-action"
          type="button"
          onClick={onReset}
          aria-label="Reset timer"
          title="Reset timer"
          data-testid="button-reset-timer"
        >
          <RotateCcw size={17} />
        </button>
      </div>

      <p className="timer-footnote" data-testid="status-timer">
        {timer.isRunning ? 'Timer keeps its place if you refresh.' : 'A gentle rhythm, at your own pace.'}
      </p>

      {completion && (
        <div className="completion-banner" role="status" aria-live="polite" data-testid="status-session-complete">
          <span className="completion-icon"><Check size={17} /></span>
          <span>
            <strong>{completion === 'focus' ? 'Beautiful work.' : 'That was a good pause.'}</strong>
            <small>{completion === 'focus' ? 'Your focus session is complete.' : 'Your break is complete. Return when you’re ready.'}</small>
          </span>
          <button type="button" onClick={onDismissCompletion} aria-label="Dismiss session complete message" data-testid="button-dismiss-completion">Dismiss</button>
        </div>
      )}
    </section>
  );
}
